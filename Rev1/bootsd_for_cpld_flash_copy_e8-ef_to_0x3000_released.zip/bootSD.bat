..\ca65 -l bootSD.lst bootSD.65s
..\cl65 bootSD.o -o bootSD.bin -C tinyload.cfg 
..\bin2hex /o0x1000 bootSD.bin bootSD.hex
