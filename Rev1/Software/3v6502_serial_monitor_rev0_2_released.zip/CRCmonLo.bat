..\ca65 -l CRCmonLo.lst CRCmonLo.65s
..\cl65 CRCmonLo.o -o CRCmonLo.bin -C CRCmon.cfg 
..\bin2hex /o0x3000 CRCmonLo.bin CRCmonLo.hex
