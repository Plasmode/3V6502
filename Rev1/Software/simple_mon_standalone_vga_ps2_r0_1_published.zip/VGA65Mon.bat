..\ca65 -l VGA65Mon.lst VGA65Mon.65s
..\cl65 VGA65Mon.o -o VGA65Mon.bin -C VGA65tst.cfg 
..\bin2hex /o0x800 VGA65Mon.bin VGA65Mon.hex
