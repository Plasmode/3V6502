module ROM_CF_boot( 
    input [4:0]addr, 
    output reg [7:0]ROMdata); 
//source file is romCFbt.65s    
    always @(*)
    begin
    //embedded 6502 instruction in ROM
        case(addr)
									//readbsy:
        5'b00000: ROMdata = 8'had; // LDA CFstat
        5'b00001: ROMdata = 8'h07; 
									
        5'b00010: ROMdata = 8'hf0; // 
        5'b00011: ROMdata = 8'h30; // BMI readbsy
        5'b00100: ROMdata = 8'hfb; // 
        5'b00101: ROMdata = 8'ha2; // LDX #$20
        5'b00110: ROMdata = 8'h20; // 
        5'b00111: ROMdata = 8'h8e; // STX CFstat
        5'b01000: ROMdata = 8'h07; //  
        5'b01001: ROMdata = 8'hf0; // 
									//chkdrq:
        5'b01010: ROMdata = 8'had; // LDA CFstat
        5'b01011: ROMdata = 8'h07; // 
        5'b01100: ROMdata = 8'hf0; // 
        5'b01101: ROMdata = 8'h29; // AND #8 
        5'b01110: ROMdata = 8'h08; //  
        5'b01111: ROMdata = 8'hf0; // BEQ chkdrq
        5'b10000: ROMdata = 8'hf9; // 
									//getCFdata:
        5'b10001: ROMdata = 8'had; // LDA CFdata
        5'b10010: ROMdata = 8'h00; // 
        5'b10011: ROMdata = 8'hf0; //   
        5'b10100: ROMdata = 8'h9d; // STA $dfe2,x 
        5'b10101: ROMdata = 8'he2; // 
        5'b10110: ROMdata = 8'hdf; // 
        5'b10111: ROMdata = 8'he8; // INX
        5'b11000: ROMdata = 8'hd0; // BNE getCFdata
        5'b11001: ROMdata = 8'hf7; //
        5'b11010: ROMdata = 8'h4c; // JMP $e002
        5'b11011: ROMdata = 8'h02; // 
        5'b11100: ROMdata = 8'he0; // reset vector
        5'b11101: ROMdata = 8'hff; // 
        5'b11110: ROMdata = 8'h00; // irq vector
        5'b11111: ROMdata = 8'h02; // 

            
        endcase
    end
endmodule