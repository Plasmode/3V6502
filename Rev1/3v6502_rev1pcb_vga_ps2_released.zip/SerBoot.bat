ca65 -l SerBoot.lst SerBoot.65s
cl65 SerBoot.o -o SerBoot.bin -C 3v6502.cfg
bin2hex -o0xffc0 SerBoot.bin SerBoot.hex
